﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace SimpleProject
{
    public partial class Login : Form
    {
        String connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Users.mdf;Integrated Security=True";
        SqlConnection myConnection = default(SqlConnection);
       

        SqlCommand myCommand = default(SqlCommand);

        public Login()
        {
            InitializeComponent();

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new RegistrationForm();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }

        private void txtTitle_Click(object sender, EventArgs e)
        {

        }

        private void lable_Click(object sender, EventArgs e)
        {

        }
        private Boolean isAllFieldsFill()
        {

            return !String.IsNullOrEmpty(txtPassword.Text)
                && !String.IsNullOrEmpty(txtUserName.Text);



        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!isAllFieldsFill())
            {
                MessageBox.Show("Please fill in all fields");

            }
            else
            {
                try
                {
                    myConnection = new SqlConnection(connectionString);

                    if (login().Read() == true)
                    {
                        MessageBox.Show("You have logged in successfully " + txtUserName.Text);

                        this.Hide();
                        var form2 = new Dashboard();
                        form2.Closed += (s, args) => this.Close();
                        form2.Show();
                    }

                    else
                    {
                        MessageBox.Show("Login Failed...Try again !", "Login Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        txtUserName.Clear();
                        txtPassword.Clear();
                        txtUserName.Focus();

                    }
                    if (myConnection.State == ConnectionState.Open)
                    {
                        myConnection.Dispose();
                    }

                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private SqlDataReader login()
        {


            string selectQuery = "SELECT Username,Password FROM Users WHERE UserName = @Username AND Password = @Password";
            myCommand = new SqlCommand(selectQuery, myConnection);
            SqlParameter uName = new SqlParameter("@Username", SqlDbType.VarChar);
            SqlParameter uPassword = new SqlParameter("@Password", SqlDbType.VarChar);


            uName.Value = txtUserName.Text;
            uPassword.Value = EncodePasswordToBase64(txtPassword.Text);

            myCommand.Parameters.Add(uName);
            myCommand.Parameters.Add(uPassword);

            myCommand.Connection.Open();

            SqlDataReader myReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection);
            return myReader;

        }



        private void txtUserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }



        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void checkBoxShowHiddenPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowHiddenPassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        public static string EncodePasswordToBase64(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        }

    }
}
