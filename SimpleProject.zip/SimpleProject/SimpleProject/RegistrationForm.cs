﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SimpleProject
{
    public partial class RegistrationForm : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["SimpleProject.Properties.Settings.UsersConnectionString"].ConnectionString;
        SqlConnection myConnection = default(SqlConnection);
        SqlCommand myCommand = default(SqlCommand);


        public RegistrationForm()
        {
            InitializeComponent();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        { 

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteRegistration_Click(object sender, EventArgs e)
        {
            txtAgeRegristraion.Clear();
            txtEmailRegistration.Clear();
            txtNameRegistration.Clear();
            txtPasswordRegistration.Clear();
            txtSurnameRegistration.Clear();
            txtUserNameRegistration.Clear();
            radioMale.Checked = false;
            radionFemale.Checked = false;
        }

        private void btnCloseRegistration_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            var form2 = new Login();
            form2.Closed += (s, args) => this.Close();
            form2.Show();
        }
        private Boolean isAllFieldsFill()
        {
            return !String.IsNullOrEmpty(txtUserNameRegistration.Text)
                && !String.IsNullOrEmpty(txtSurnameRegistration.Text)
                && !String.IsNullOrEmpty(txtPasswordRegistration.Text)
                && !String.IsNullOrEmpty(txtNameRegistration.Text)
                && !String.IsNullOrEmpty(txtEmailRegistration.Text)
                && !String.IsNullOrEmpty(txtAgeRegristraion.Text);
        }

        private void btnSaveRegistration_Click(object sender, EventArgs e)
        {
            if (!isAllFieldsFill())
            {
                MessageBox.Show("Please fill in all fields");
            }
            else
            {
                myConnection = new SqlConnection(connectionString);

                if (existingUserNameCheck() != null)
                {
                    MessageBox.Show(string.Format("Username {0} already exist", this.txtUserNameRegistration.Text));
                }
                else
                {
                    if (createNewUser() == 1)
                    {
                        MessageBox.Show("You have succesfully created user");
                        txtAgeRegristraion.Clear();
                        txtEmailRegistration.Clear();
                        txtNameRegistration.Clear();
                        txtPasswordRegistration.Clear();
                        txtSurnameRegistration.Clear();
                        txtUserNameRegistration.Clear();
                        radioMale.Checked = false;
                        radionFemale.Checked = false;
                    }
                    if (createNewUser() == 0)
                    {
                        MessageBox.Show("Something went wrong, please try again");
                    }
                    myConnection.Close();
                }
            }
        }

        private object existingUserNameCheck()
        {
            myConnection.Open();
            string selectQuery = "Select Id from Users where UserName= @UserName";
            myCommand = new SqlCommand(selectQuery, myConnection);
            myCommand.Parameters.AddWithValue("@UserName", txtUserNameRegistration.Text);
            var resultExistingUser = myCommand.ExecuteScalar();
            return resultExistingUser;
        }

        private int createNewUser()
        {
            string Insertquery = "INSERT INTO Users VALUES (@UserName, @Password , @Gender, @Email, @Name, @Surname, @DataOfBirth)";
            myCommand = new SqlCommand(Insertquery, myConnection);
            myCommand.Parameters.AddWithValue("@UserName", txtUserNameRegistration.Text);
            myCommand.Parameters.AddWithValue("@Password", EncodePasswordToBase64(txtPasswordRegistration.Text));
            if (radionFemale.Checked)
            {
                myCommand.Parameters.AddWithValue("@Gender", radionFemale.Text);
            }
            else
            {
                myCommand.Parameters.AddWithValue("@Gender", radioMale.Text);

            }
            myCommand.Parameters.AddWithValue("@Email", txtEmailRegistration.Text);
            myCommand.Parameters.AddWithValue("@Name", txtNameRegistration.Text);
            myCommand.Parameters.AddWithValue("@Surname", txtSurnameRegistration.Text);
            myCommand.Parameters.AddWithValue("@DataOfBirth", txtAgeRegristraion.Text);

            int resultNewUser = myCommand.ExecuteNonQuery();
            return resultNewUser;
        }

        private void txtPasswordRegistration_TextChanged(object sender, EventArgs e)
        {
            txtPasswordRegistration.UseSystemPasswordChar = true;
        }
        public static string EncodePasswordToBase64(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        }

        private void radioMale_CheckedChanged(object sender, EventArgs e)
        {
        }
    }

}

