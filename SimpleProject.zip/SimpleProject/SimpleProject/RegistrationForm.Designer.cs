﻿namespace SimpleProject
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUserNameRegistration = new System.Windows.Forms.TextBox();
            this.txtPasswordRegistration = new System.Windows.Forms.TextBox();
            this.txtNameRegistration = new System.Windows.Forms.TextBox();
            this.txtSurnameRegistration = new System.Windows.Forms.TextBox();
            this.txtAgeRegristraion = new System.Windows.Forms.TextBox();
            this.txtEmailRegistration = new System.Windows.Forms.TextBox();
            this.radionFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.btnSaveRegistration = new System.Windows.Forms.Button();
            this.btnClearRegistration = new System.Windows.Forms.Button();
            this.btnCloseRegistration = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registration";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(43, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(43, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Surname";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(43, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(43, 214);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Age";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtUserNameRegistration
            // 
            this.txtUserNameRegistration.Location = new System.Drawing.Point(156, 107);
            this.txtUserNameRegistration.Name = "txtUserNameRegistration";
            this.txtUserNameRegistration.Size = new System.Drawing.Size(132, 20);
            this.txtUserNameRegistration.TabIndex = 8;
            // 
            // txtPasswordRegistration
            // 
            this.txtPasswordRegistration.Location = new System.Drawing.Point(156, 133);
            this.txtPasswordRegistration.Name = "txtPasswordRegistration";
            this.txtPasswordRegistration.Size = new System.Drawing.Size(132, 20);
            this.txtPasswordRegistration.TabIndex = 9;
            this.txtPasswordRegistration.TextChanged += new System.EventHandler(this.txtPasswordRegistration_TextChanged);
            // 
            // txtNameRegistration
            // 
            this.txtNameRegistration.Location = new System.Drawing.Point(156, 159);
            this.txtNameRegistration.Name = "txtNameRegistration";
            this.txtNameRegistration.Size = new System.Drawing.Size(132, 20);
            this.txtNameRegistration.TabIndex = 10;
            // 
            // txtSurnameRegistration
            // 
            this.txtSurnameRegistration.Location = new System.Drawing.Point(156, 185);
            this.txtSurnameRegistration.Name = "txtSurnameRegistration";
            this.txtSurnameRegistration.Size = new System.Drawing.Size(132, 20);
            this.txtSurnameRegistration.TabIndex = 11;
            // 
            // txtAgeRegristraion
            // 
            this.txtAgeRegristraion.Location = new System.Drawing.Point(156, 211);
            this.txtAgeRegristraion.Name = "txtAgeRegristraion";
            this.txtAgeRegristraion.Size = new System.Drawing.Size(132, 20);
            this.txtAgeRegristraion.TabIndex = 13;
            // 
            // txtEmailRegistration
            // 
            this.txtEmailRegistration.Location = new System.Drawing.Point(156, 237);
            this.txtEmailRegistration.Name = "txtEmailRegistration";
            this.txtEmailRegistration.Size = new System.Drawing.Size(132, 20);
            this.txtEmailRegistration.TabIndex = 14;
            // 
            // radionFemale
            // 
            this.radionFemale.AutoSize = true;
            this.radionFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radionFemale.Location = new System.Drawing.Point(46, 273);
            this.radionFemale.Name = "radionFemale";
            this.radionFemale.Size = new System.Drawing.Size(80, 24);
            this.radionFemale.TabIndex = 1;
            this.radionFemale.Text = "Female";
            this.radionFemale.UseVisualStyleBackColor = true;
            this.radionFemale.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioMale.Location = new System.Drawing.Point(163, 273);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(61, 24);
            this.radioMale.TabIndex = 18;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            this.radioMale.CheckedChanged += new System.EventHandler(this.radioMale_CheckedChanged);
            // 
            // btnSaveRegistration
            // 
            this.btnSaveRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveRegistration.Location = new System.Drawing.Point(27, 332);
            this.btnSaveRegistration.Name = "btnSaveRegistration";
            this.btnSaveRegistration.Size = new System.Drawing.Size(75, 29);
            this.btnSaveRegistration.TabIndex = 19;
            this.btnSaveRegistration.Text = "Save";
            this.btnSaveRegistration.UseVisualStyleBackColor = true;
            this.btnSaveRegistration.Click += new System.EventHandler(this.btnSaveRegistration_Click);
            // 
            // btnClearRegistration
            // 
            this.btnClearRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearRegistration.Location = new System.Drawing.Point(213, 332);
            this.btnClearRegistration.Name = "btnClearRegistration";
            this.btnClearRegistration.Size = new System.Drawing.Size(75, 29);
            this.btnClearRegistration.TabIndex = 20;
            this.btnClearRegistration.Text = "Clear";
            this.btnClearRegistration.UseVisualStyleBackColor = true;
            this.btnClearRegistration.Click += new System.EventHandler(this.btnDeleteRegistration_Click);
            // 
            // btnCloseRegistration
            // 
            this.btnCloseRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseRegistration.Location = new System.Drawing.Point(321, 25);
            this.btnCloseRegistration.Name = "btnCloseRegistration";
            this.btnCloseRegistration.Size = new System.Drawing.Size(75, 30);
            this.btnCloseRegistration.TabIndex = 21;
            this.btnCloseRegistration.Text = "Close";
            this.btnCloseRegistration.UseVisualStyleBackColor = true;
            this.btnCloseRegistration.Click += new System.EventHandler(this.btnCloseRegistration_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(119, 332);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 29);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 372);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnCloseRegistration);
            this.Controls.Add(this.btnClearRegistration);
            this.Controls.Add(this.btnSaveRegistration);
            this.Controls.Add(this.radioMale);
            this.Controls.Add(this.radionFemale);
            this.Controls.Add(this.txtEmailRegistration);
            this.Controls.Add(this.txtAgeRegristraion);
            this.Controls.Add(this.txtSurnameRegistration);
            this.Controls.Add(this.txtNameRegistration);
            this.Controls.Add(this.txtPasswordRegistration);
            this.Controls.Add(this.txtUserNameRegistration);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "RegistrationForm";
            this.Text = "RegistrationForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUserNameRegistration;
        private System.Windows.Forms.TextBox txtPasswordRegistration;
        private System.Windows.Forms.TextBox txtNameRegistration;
        private System.Windows.Forms.TextBox txtSurnameRegistration;
        private System.Windows.Forms.TextBox txtAgeRegristraion;
        private System.Windows.Forms.TextBox txtEmailRegistration;
        private System.Windows.Forms.RadioButton radionFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.Button btnSaveRegistration;
        private System.Windows.Forms.Button btnClearRegistration;
        private System.Windows.Forms.Button btnCloseRegistration;
        private System.Windows.Forms.Button btnBack;
    }
}