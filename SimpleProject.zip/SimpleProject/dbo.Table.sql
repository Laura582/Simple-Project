﻿CREATE TABLE [dbo].Users
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [UserName] TEXT NOT NULL, 
    [Password] TEXT NOT NULL, 
    [Gender] TEXT NOT NULL, 
    [Email] TEXT NOT NULL, 
    [Name] TEXT NOT NULL, 
    [Surname] TEXT NOT NULL, 
    [DateOfBirth] TEXT NOT NULL
)
